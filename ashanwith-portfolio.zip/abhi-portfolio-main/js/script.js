var typed = new Typed(".typing",{
    strings:["Web Designer","Python Application Developer","Backend Developer"],
    typeSpeed:90,
    BackSpeed:60,
    loop:true
})